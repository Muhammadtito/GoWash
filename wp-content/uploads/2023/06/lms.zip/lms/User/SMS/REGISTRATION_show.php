 <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'Registration  Complete !',
                        'position'  :   'right'
                    });
                });
                
    </script>
    