 <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'Record Upload !',
                        'position'  :   'right'
                    });
                });
                
    </script>
    