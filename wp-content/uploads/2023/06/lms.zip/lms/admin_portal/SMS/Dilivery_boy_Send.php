 <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'Delivery boy send!',
                        'position'  :   'right'
                    });
                });
                
    </script>
    